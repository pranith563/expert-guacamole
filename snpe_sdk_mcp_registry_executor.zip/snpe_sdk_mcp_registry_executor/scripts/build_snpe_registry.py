from __future__ import annotations

import argparse
import hashlib
import os
import subprocess
import time
from pathlib import Path
from typing import Dict, List, Tuple

from snpe_sdk.config import load_config
from snpe_sdk.registry.help_parser import parse_help_to_args
from snpe_sdk.registry.registry_io import save_manifest, save_tool_spec
from snpe_sdk.registry.registry_types import (
    RegistryManifest,
    RegistryManifestTool,
    ToolArg,
    ToolSpec,
)


def _sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _sha256_file(p: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        while True:
            b = f.read(chunk_size)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def _run_capture(argv: List[str], env: Dict[str, str]) -> Tuple[int, str]:
    try:
        out = subprocess.check_output(argv, env=env, stderr=subprocess.STDOUT, text=True)
        return 0, out
    except subprocess.CalledProcessError as e:
        return e.returncode, e.output or ""
    except FileNotFoundError:
        return 127, ""
    except Exception as e:
        return 1, str(e)


def _resolve_tool_path(bin_dirs: List[str], tool_path: str) -> Path:
    p = Path(tool_path).expanduser()
    if p.is_absolute():
        return p.resolve()
    for bd in bin_dirs:
        cand = (Path(bd) / tool_path).expanduser()
        if cand.exists():
            return cand.resolve()
    return p  # unresolved; will likely fail at runtime


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True, help="Path to configs/snpe.yaml")
    args = ap.parse_args()

    cfg = load_config(args.config)
    sdk_root = Path(cfg.snpe.sdk_root).expanduser().resolve()
    registry_root = Path(cfg.registry.root_dir).expanduser().resolve()

    sdk_version = (cfg.registry.sdk_version or "").strip()
    if not sdk_version:
        sdk_version = time.strftime("%Y%m%d_%H%M%S")

    # Apply env additions to help/version capture too
    env = dict(os.environ)
    for k, parts in cfg.snpe.env.items():
        cur = env.get(k, "")
        prefix = ":".join(parts)
        env[k] = f"{prefix}:{cur}" if cur else prefix

    tools_manifest: List[RegistryManifestTool] = []
    built_at = time.strftime("%Y-%m-%dT%H:%M:%S%z")

    for tool_name, tool_rel in cfg.snpe.allowlist.items():
        tool_abs = _resolve_tool_path(cfg.snpe.bin_dirs, tool_rel)

        help_raw = ""
        version_raw = ""
        args_parsed = []
        bin_sha = ""
        mtime = 0.0
        size = 0

        if tool_abs.exists():
            _, help_raw = _run_capture([str(tool_abs), "--help"], env)
            if not help_raw:
                _, help_raw = _run_capture([str(tool_abs), "-h"], env)

            _, version_raw = _run_capture([str(tool_abs), "--version"], env)
            args_parsed = parse_help_to_args(help_raw)

            st = tool_abs.stat()
            mtime, size = st.st_mtime, st.st_size
            bin_sha = _sha256_file(tool_abs)

        help_sha = _sha256_bytes(help_raw.encode("utf-8", errors="ignore"))
        ver_sha = _sha256_bytes(version_raw.encode("utf-8", errors="ignore"))

        spec = ToolSpec(
            sdk="snpe",
            sdk_version=sdk_version,
            name=tool_name,
            abs_path=str(tool_abs),
            description=f"Auto-captured spec for {tool_name}",
            captured_at=built_at,
            help_raw=help_raw,
            version_raw=version_raw,
            args=[ToolArg(**a.__dict__) for a in args_parsed],
            examples=[],
        )
        save_tool_spec(registry_root, spec)

        tools_manifest.append(
            RegistryManifestTool(
                name=tool_name,
                abs_path=str(tool_abs),
                bin_sha256=bin_sha,
                bin_mtime=mtime,
                bin_size=size,
                help_sha256=help_sha,
                version_sha256=ver_sha,
            )
        )

    manifest = RegistryManifest(
        sdk="snpe",
        sdk_root=str(sdk_root),
        sdk_version=sdk_version,
        built_at=built_at,
        tools=tools_manifest,
    )
    save_manifest(registry_root, manifest)

    print(f"Registry built: {registry_root}/snpe/{sdk_version}/")
    print(f"Tools captured: {len(tools_manifest)}")


if __name__ == "__main__":
    main()
