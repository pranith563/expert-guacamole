from __future__ import annotations

from typing import Dict, List, Optional
from pydantic import BaseModel, Field


class ToolArg(BaseModel):
    flags: List[str]
    takes_value: bool
    metavar: Optional[str] = None
    repeatable: bool = False
    type_hint: str = "string"
    help: str = ""


class ToolExample(BaseModel):
    title: str
    argv: List[str]


class ToolSpec(BaseModel):
    sdk: str = "snpe"
    sdk_version: str
    name: str
    abs_path: str
    description: str = ""
    captured_at: str
    help_raw: str
    version_raw: str = ""
    args: List[ToolArg] = Field(default_factory=list)
    examples: List[ToolExample] = Field(default_factory=list)


class RegistryManifestTool(BaseModel):
    name: str
    abs_path: str
    bin_sha256: str
    bin_mtime: float
    bin_size: int
    help_sha256: str
    version_sha256: str


class RegistryManifest(BaseModel):
    sdk: str = "snpe"
    sdk_root: str
    sdk_version: str
    built_at: str
    tools: List[RegistryManifestTool]
