from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from mcp.server.fastmcp import FastMCP

from snpe_sdk.config import load_config
from snpe_sdk.registry.registry_io import load_manifest, load_tool_spec
from snpe_sdk.exec.path_resolver import PathConfig
from snpe_sdk.exec.runner import ExecConfig, dry_run as exec_dry_run, run as exec_run


mcp = FastMCP("snpe-sdk-mcp", json_response=True)


def _resolve_allowlist(cfg) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for name, rel in cfg.snpe.allowlist.items():
        p = Path(rel).expanduser()
        if p.is_absolute():
            out[name] = str(p.resolve())
            continue
        found = None
        for bd in cfg.snpe.bin_dirs:
            cand = (Path(bd) / rel).expanduser()
            if cand.exists():
                found = cand.resolve()
                break
        out[name] = str(found if found else p)
    return out


def _workdir_from_workspace(workspace: Dict[str, Any], cfg) -> Path:
    exp_id = workspace.get("experiment_id") or "exp_unknown"
    workdir = workspace.get("workdir") or f"exp://{exp_id}/snpe"
    if isinstance(workdir, str) and workdir.startswith("exp://"):
        rel = workdir[len("exp://"):].lstrip("/")
        return (Path(cfg.paths.workspace_root) / rel).resolve()
    p = Path(str(workdir))
    if not p.is_absolute():
        p = (Path(cfg.paths.workspace_root) / exp_id / p).resolve()
    return p


def _artifact_dir(workspace: Dict[str, Any], cfg) -> Path:
    exp_id = workspace.get("experiment_id") or "exp_unknown"
    return (Path(cfg.paths.artifacts_root) / exp_id / "artifacts").resolve()


def _exec_config(cfg, registry_root: Path) -> ExecConfig:
    path_cfg = PathConfig(
        allowed_input_roots=[Path(p).expanduser().resolve() for p in cfg.paths.allowed_input_roots],
        workspace_root=Path(cfg.paths.workspace_root).expanduser().resolve(),
        artifacts_root=Path(cfg.paths.artifacts_root).expanduser().resolve(),
        modelhub_root=Path(os.environ.get("MODELHUB_ROOT")).expanduser().resolve() if os.environ.get("MODELHUB_ROOT") else None,
    )
    return ExecConfig(
        sdk_root=Path(cfg.snpe.sdk_root).expanduser().resolve(),
        env_additions=cfg.snpe.env,
        allowlist=_resolve_allowlist(cfg),
        path_cfg=path_cfg,
        registry_root=registry_root,
    )


@mcp.tool()
def snpe_list_tools(config_path: str, sdk_version: Optional[str] = None) -> Dict[str, Any]:
    """List allowlisted SNPE tools from the generated registry."""
    cfg = load_config(config_path)
    registry_root = Path(cfg.registry.root_dir).expanduser().resolve()
    if not sdk_version:
        snpe_dir = registry_root / "snpe"
        if not snpe_dir.exists():
            return {"tools": [], "sdk_version": None, "note": "Registry not found. Run scripts/build_snpe_registry.py first."}
        versions = sorted([p.name for p in snpe_dir.iterdir() if p.is_dir()])
        sdk_version = versions[-1] if versions else None
    if not sdk_version:
        return {"tools": [], "sdk_version": None}

    manifest = load_manifest(registry_root, "snpe", sdk_version)
    tools = [{"name": t.name, "abs_path": t.abs_path} for t in manifest.tools]
    return {"sdk_version": sdk_version, "tools": tools}


@mcp.tool()
def snpe_get_tool_spec(config_path: str, tool_name: str, sdk_version: Optional[str] = None) -> Dict[str, Any]:
    """Return the stored tool spec (including raw help) for an allowlisted SNPE tool."""
    cfg = load_config(config_path)
    registry_root = Path(cfg.registry.root_dir).expanduser().resolve()
    if not sdk_version:
        snpe_dir = registry_root / "snpe"
        if not snpe_dir.exists():
            return {"error": "Registry not found. Run scripts/build_snpe_registry.py first."}
        versions = sorted([p.name for p in snpe_dir.iterdir() if p.is_dir()])
        sdk_version = versions[-1] if versions else None
    if not sdk_version:
        return {"error": "No sdk_version found."}

    spec = load_tool_spec(registry_root, "snpe", sdk_version, tool_name)
    return spec.model_dump()


@mcp.tool()
def snpe_dry_run(
    config_path: str,
    tool_name: str,
    args: Dict[str, Any],
    workspace: Dict[str, Any],
    sdk_version: Optional[str] = None,
    extra_args: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Validate + build argv for an allowlisted SNPE tool (does not execute)."""
    cfg = load_config(config_path)
    registry_root = Path(cfg.registry.root_dir).expanduser().resolve()
    if not sdk_version:
        snpe_dir = registry_root / "snpe"
        if not snpe_dir.exists():
            return {"error": "Registry not found. Run scripts/build_snpe_registry.py first."}
        versions = sorted([p.name for p in snpe_dir.iterdir() if p.is_dir()])
        sdk_version = versions[-1] if versions else None
    if not sdk_version:
        return {"error": "No sdk_version found."}

    spec = load_tool_spec(registry_root, "snpe", sdk_version, tool_name)
    ecfg = _exec_config(cfg, registry_root)
    workdir = _workdir_from_workspace(workspace, cfg)

    return exec_dry_run(ecfg, spec, request_args=args, extra_args=extra_args or [], workdir=workdir)


@mcp.tool()
def snpe_run(
    config_path: str,
    tool_name: str,
    args: Dict[str, Any],
    workspace: Dict[str, Any],
    sdk_version: Optional[str] = None,
    extra_args: Optional[List[str]] = None,
    timeout_s: Optional[int] = None,
) -> Dict[str, Any]:
    """Execute an allowlisted SNPE tool; writes logs + manifest under artifact dir."""
    cfg = load_config(config_path)
    registry_root = Path(cfg.registry.root_dir).expanduser().resolve()
    if not sdk_version:
        snpe_dir = registry_root / "snpe"
        if not snpe_dir.exists():
            return {"error": "Registry not found. Run scripts/build_snpe_registry.py first."}
        versions = sorted([p.name for p in snpe_dir.iterdir() if p.is_dir()])
        sdk_version = versions[-1] if versions else None
    if not sdk_version:
        return {"error": "No sdk_version found."}

    spec = load_tool_spec(registry_root, "snpe", sdk_version, tool_name)
    ecfg = _exec_config(cfg, registry_root)
    workdir = _workdir_from_workspace(workspace, cfg)
    artifact_dir = _artifact_dir(workspace, cfg)

    return exec_run(
        ecfg,
        spec,
        request_args=args,
        extra_args=extra_args or [],
        workdir=workdir,
        artifact_dir=artifact_dir,
        timeout_s=timeout_s,
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True, help="Path to configs/snpe.yaml")
    ap.add_argument("--host", default=None)
    ap.add_argument("--port", type=int, default=None)
    a = ap.parse_args()

    cfg = load_config(a.config)
    host = a.host or cfg.server.host
    port = a.port or cfg.server.port

    # Streamable HTTP MCP server at http://host:port/mcp
    mcp.run(transport="streamable-http", host=host, port=port)


if __name__ == "__main__":
    main()
