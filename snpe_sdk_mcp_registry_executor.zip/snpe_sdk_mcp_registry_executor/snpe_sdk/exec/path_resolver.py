from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional


@dataclass(frozen=True)
class PathConfig:
    allowed_input_roots: list[Path]
    workspace_root: Path
    artifacts_root: Path
    modelhub_root: Optional[Path] = None


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False


def ensure_under_allowed_roots(path: Path, allowed_roots: Iterable[Path]) -> None:
    resolved = path.resolve()
    for r in allowed_roots:
        if _is_within(resolved, r):
            return
    raise ValueError(f"Path not allowed (outside roots): {resolved}")


def resolve_uri(value: str, cfg: PathConfig, *, cwd: Path) -> Path:
    value = value.strip()

    if value.startswith("modelhub://"):
        rel = value[len("modelhub://") :].lstrip("/")
        modelhub_root = cfg.modelhub_root or _infer_modelhub_root()
        if modelhub_root is None:
            raise ValueError("modelhub:// used but MODELHUB_ROOT (or modelhub_root) is not configured")
        p = (modelhub_root / rel).resolve()
        ensure_under_allowed_roots(p, cfg.allowed_input_roots + [modelhub_root])
        return p

    if value.startswith("exp://"):
        rel = value[len("exp://") :].lstrip("/")
        p = (cfg.workspace_root / rel).resolve()
        ensure_under_allowed_roots(p, [cfg.workspace_root])
        return p

    if value.startswith("artifact://"):
        rel = value[len("artifact://") :].lstrip("/")
        p = (cfg.artifacts_root / rel).resolve()
        ensure_under_allowed_roots(p, [cfg.artifacts_root])
        return p

    p = Path(value)
    if not p.is_absolute():
        p = (cwd / p).resolve()

    ensure_under_allowed_roots(p, cfg.allowed_input_roots + [cfg.workspace_root, cfg.artifacts_root])
    return p


def _infer_modelhub_root() -> Optional[Path]:
    env = os.environ.get("MODELHUB_ROOT")
    if env:
        return Path(env).expanduser().resolve()
    return None
