from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    import hashlib
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(chunk_size)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


@dataclass
class RunManifest:
    sdk: str
    sdk_version: str
    tool_name: str
    tool_abs_path: str
    argv: List[str]
    cwd: str
    env_additions: Dict[str, List[str]]
    started_at: float
    finished_at: Optional[float] = None
    exit_code: Optional[int] = None
    stdout_path: Optional[str] = None
    stderr_path: Optional[str] = None
    inputs: Optional[Dict[str, str]] = None
    outputs: Optional[Dict[str, str]] = None
    input_hashes: Optional[Dict[str, str]] = None
    output_hashes: Optional[Dict[str, str]] = None
    tool_bin_sha256: Optional[str] = None
    tool_help_sha256: Optional[str] = None
    tool_version_sha256: Optional[str] = None
    warnings: Optional[List[str]] = None


def write_manifest(path: Path, manifest: RunManifest) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(manifest.__dict__, indent=2, sort_keys=True), encoding="utf-8")
