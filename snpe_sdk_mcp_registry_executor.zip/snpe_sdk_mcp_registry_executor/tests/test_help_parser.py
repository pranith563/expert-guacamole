from snpe_sdk.registry.help_parser import parse_help_to_args

def test_parse_basic():
    help_raw = """Options:
  --foo BAR   Some help text
  -b, --baz   Baz flag
"""
    args = parse_help_to_args(help_raw)
    assert any("--foo" in a.flags for a in args)
    assert any("--baz" in a.flags for a in args)
