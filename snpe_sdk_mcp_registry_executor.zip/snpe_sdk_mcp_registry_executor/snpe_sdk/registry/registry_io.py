from __future__ import annotations

from pathlib import Path
from .registry_types import ToolSpec, RegistryManifest


def registry_dir(root_dir: Path, sdk: str, sdk_version: str) -> Path:
    return root_dir / sdk / sdk_version


def tool_spec_path(root_dir: Path, sdk: str, sdk_version: str, tool_name: str) -> Path:
    return registry_dir(root_dir, sdk, sdk_version) / "tools" / f"{tool_name}.json"


def manifest_path(root_dir: Path, sdk: str, sdk_version: str) -> Path:
    return registry_dir(root_dir, sdk, sdk_version) / "registry_manifest.json"


def load_tool_spec(root_dir: Path, sdk: str, sdk_version: str, tool_name: str) -> ToolSpec:
    p = tool_spec_path(root_dir, sdk, sdk_version, tool_name)
    return ToolSpec.model_validate_json(p.read_text(encoding="utf-8"))


def load_manifest(root_dir: Path, sdk: str, sdk_version: str) -> RegistryManifest:
    p = manifest_path(root_dir, sdk, sdk_version)
    return RegistryManifest.model_validate_json(p.read_text(encoding="utf-8"))


def save_tool_spec(root_dir: Path, spec: ToolSpec) -> None:
    p = tool_spec_path(root_dir, spec.sdk, spec.sdk_version, spec.name)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(spec.model_dump_json(indent=2), encoding="utf-8")


def save_manifest(root_dir: Path, manifest: RegistryManifest) -> None:
    p = manifest_path(root_dir, manifest.sdk, manifest.sdk_version)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(manifest.model_dump_json(indent=2), encoding="utf-8")
