from __future__ import annotations

from pathlib import Path
from typing import Dict, List
import yaml
from pydantic import BaseModel, Field


class SnpeConfig(BaseModel):
    sdk_root: str
    bin_dirs: List[str]
    env: Dict[str, List[str]] = Field(default_factory=dict)
    allowlist: Dict[str, str] = Field(default_factory=dict)


class PathsConfig(BaseModel):
    allowed_input_roots: List[str]
    workspace_root: str
    artifacts_root: str


class RegistryConfig(BaseModel):
    root_dir: str
    sdk_version: str = ""


class ServerConfig(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8210


class AppConfig(BaseModel):
    snpe: SnpeConfig
    paths: PathsConfig
    registry: RegistryConfig
    server: ServerConfig = ServerConfig()


def load_config(path: str | Path) -> AppConfig:
    p = Path(path)
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}

    snpe = data.get("snpe", {})
    sdk_root = snpe.get("sdk_root", "")

    def _fmt(s: str) -> str:
        return s.format(sdk_root=sdk_root)

    snpe["bin_dirs"] = [_fmt(x) for x in snpe.get("bin_dirs", [])]
    snpe_env = snpe.get("env", {})
    for k, v in list(snpe_env.items()):
        snpe_env[k] = [_fmt(x) for x in v]
    snpe["env"] = snpe_env

    data["snpe"] = snpe
    return AppConfig.model_validate(data)
