from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional


@dataclass(frozen=True)
class ParsedArg:
    flags: List[str]
    takes_value: bool
    metavar: Optional[str]
    repeatable: bool
    type_hint: str
    help: str


_FLAG_LINE_RE = re.compile(
    r"^\s*(?P<spec>(?:-\w(?:,\s*)?)?(?:--[A-Za-z0-9][A-Za-z0-9_\-]*)(?:[ =][^\s].*)?)\s{2,}(?P<help>.+)$"
)
_FLAG_TOKEN_RE = re.compile(r"(?P<flag>--[A-Za-z0-9][A-Za-z0-9_\-]*|-\w)\b")


def _infer_takes_value(spec: str) -> tuple[bool, Optional[str]]:
    # Heuristics: `--flag VALUE`, `--flag <VALUE>`, `--flag=VALUE`
    if "=" in spec and spec.strip().startswith("--"):
        parts = spec.split("=", 1)
        if len(parts) == 2 and parts[1].strip():
            return True, parts[1].strip()
    tokens = spec.strip().split()
    if len(tokens) >= 2:
        mv = " ".join(tokens[1:]).strip()
        return True, mv if mv else None
    m = re.search(r"--[A-Za-z0-9_\-]+\s*<([^>]+)>", spec)
    if m:
        return True, m.group(1)
    return False, None


def _infer_type_hint(metavar: Optional[str], help_text: str) -> str:
    text = f"{metavar or ''} {help_text}".lower()
    if any(k in text for k in ["file", "path", "directory", "folder", ".dlc", ".pb", ".onnx", ".tflite"]):
        return "path"
    if any(k in text for k in ["dim", "shape", "tensor", "height", "width", "channels", "batch"]):
        return "shape"
    if any(k in text for k in ["true/false", "enable", "disable", "boolean"]):
        return "bool"
    if re.search(r"\{[^}]+\}", text) or re.search(r"\[[^\]]+\]", text):
        return "enum"
    if any(k in text for k in ["int", "integer", "float", "double", "number"]):
        return "number"
    return "string"


def parse_help_to_args(help_raw: str) -> List[ParsedArg]:
    """Best-effort parser for CLI help text."""
    args: List[ParsedArg] = []
    for line in help_raw.splitlines():
        m = _FLAG_LINE_RE.match(line)
        if not m:
            continue
        spec = m.group("spec").strip()
        help_text = m.group("help").strip()

        flags = _FLAG_TOKEN_RE.findall(spec)
        flags = list(dict.fromkeys(flags))  # stable unique

        takes_value, metavar = _infer_takes_value(spec)
        repeatable = "multiple times" in help_text.lower() or "repeat" in help_text.lower()

        type_hint = _infer_type_hint(metavar, help_text)

        if flags:
            args.append(
                ParsedArg(
                    flags=flags,
                    takes_value=takes_value,
                    metavar=metavar,
                    repeatable=repeatable,
                    type_hint=type_hint,
                    help=help_text,
                )
            )
    return args
