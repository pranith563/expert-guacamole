# SNPE SDK MCP: Registry + Bounded Executor (Streamable HTTP)

Implements:
1) Allowlisted SNPE tool registry builder (captures `--help`, best-effort parses flags, fingerprints binaries).
2) Deterministic command runner with safe argv building, path sandboxing, and run manifests.
3) MCP server exposing four tools:
   - `snpe_list_tools`
   - `snpe_get_tool_spec`
   - `snpe_dry_run`
   - `snpe_run`

## Quickstart (uv)
```bash
uv venv
source .venv/bin/activate
uv pip install -e .
```

### 1) Configure
Edit: `configs/snpe.yaml` (paths + SNPE sdk_root)

Optional env:
- `MODELHUB_ROOT=/data/modelhub`

### 2) Build registry
```bash
python scripts/build_snpe_registry.py --config configs/snpe.yaml
```

### 3) Run MCP server (Streamable HTTP)
```bash
python mcp-servers/snpe_sdk_mcp/server.py --config configs/snpe.yaml
# or:
snpe-mcp-server --config configs/snpe.yaml
```

Server endpoint:
`http://<host>:<port>/mcp`

## Notes
- `GET /mcp` often returns "Invalid or missing Session ID" for streamable endpoints — expected behavior.
- Only allowlisted tools can run.
- Every run writes logs + `manifest.json`.
