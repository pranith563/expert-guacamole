from __future__ import annotations

import os
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ..registry.registry_types import ToolSpec
from .manifest import RunManifest, sha256_file, write_manifest
from .path_resolver import PathConfig, resolve_uri


@dataclass(frozen=True)
class ExecConfig:
    sdk_root: Path
    env_additions: Dict[str, List[str]]
    allowlist: Dict[str, str]  # tool_name -> abs_path (or resolvable)
    path_cfg: PathConfig
    registry_root: Path


def _apply_env_additions(base: Dict[str, str], env_additions: Dict[str, List[str]]) -> Dict[str, str]:
    env = dict(base)
    for k, parts in env_additions.items():
        cur = env.get(k, "")
        prefix = ":".join(parts)
        env[k] = f"{prefix}:{cur}" if cur else prefix
    return env


def build_argv_from_structured_request(
    tool_spec: ToolSpec,
    request_args: Dict,
    extra_args: List[str],
    *,
    cwd: Path,
    path_cfg: PathConfig,
) -> Tuple[List[str], Dict[str, str], Dict[str, str], List[str]]:
    warnings: List[str] = []
    argv: List[str] = [tool_spec.abs_path]

    def find_flag_for_name(name: str) -> Optional[str]:
        for a in tool_spec.args:
            for f in a.flags:
                if f.startswith("--") and f[2:] == name:
                    return f
        for a in tool_spec.args:
            for f in a.flags:
                if f.startswith("--") and name.replace("_", "-") in f[2:]:
                    return f
        return None

    resolved_inputs: Dict[str, str] = {}
    resolved_outputs: Dict[str, str] = {}

    def maybe_resolve_value(v):
        if isinstance(v, str):
            if v.startswith(("modelhub://", "artifact://", "exp://")):
                return str(resolve_uri(v, path_cfg, cwd=cwd))
            if "/" in v or v.startswith("."):
                try:
                    return str(resolve_uri(v, path_cfg, cwd=cwd))
                except Exception:
                    return v
        return v

    for key, val in request_args.items():
        if key.startswith("-"):
            flag = key
        else:
            flag = find_flag_for_name(key) or f"--{key}"
            if flag == f"--{key}":
                warnings.append(f"Unknown arg name '{key}' (no matching spec flag). Passing as {flag}.")

        if isinstance(val, bool):
            if val:
                argv.append(flag)
            continue

        if isinstance(val, list):
            for item in val:
                item2 = maybe_resolve_value(item)
                argv.extend([flag, str(item2)])
            continue

        val2 = maybe_resolve_value(val)
        argv.extend([flag, str(val2)])

    argv.extend(extra_args or [])

    # lightweight input/output detection for hashing
    for k in ("input_network", "input", "model", "dlc"):
        if k in request_args and isinstance(request_args[k], str):
            try:
                resolved_inputs[k] = str(resolve_uri(request_args[k], path_cfg, cwd=cwd))
            except Exception:
                pass
    for k in ("output_path", "output_dlc", "dlc_out", "output"):
        if k in request_args and isinstance(request_args[k], str):
            try:
                resolved_outputs[k] = str(resolve_uri(request_args[k], path_cfg, cwd=cwd))
            except Exception:
                pass

    return argv, resolved_inputs, resolved_outputs, warnings


def run_subprocess(argv: List[str], env: Dict[str, str], cwd: Path, stdout_path: Path, stderr_path: Path, timeout_s: Optional[int]) -> int:
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    stderr_path.parent.mkdir(parents=True, exist_ok=True)
    with stdout_path.open("wb") as out, stderr_path.open("wb") as err:
        p = subprocess.Popen(argv, cwd=str(cwd), env=env, stdout=out, stderr=err)
        try:
            return p.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            p.kill()
            return 124


def compute_tool_fingerprints(tool_abs: Path, help_raw: str, version_raw: str) -> tuple[str, str, str]:
    import hashlib
    bin_sha = sha256_file(tool_abs) if tool_abs.exists() else ""
    help_sha = hashlib.sha256(help_raw.encode("utf-8", errors="ignore")).hexdigest()
    ver_sha = hashlib.sha256(version_raw.encode("utf-8", errors="ignore")).hexdigest()
    return bin_sha, help_sha, ver_sha


def dry_run(cfg: ExecConfig, tool_spec: ToolSpec, request_args: Dict, extra_args: List[str], workdir: Path) -> dict:
    env = _apply_env_additions(os.environ, cfg.env_additions)
    argv, resolved_inputs, resolved_outputs, warnings = build_argv_from_structured_request(
        tool_spec, request_args, extra_args, cwd=workdir, path_cfg=cfg.path_cfg
    )
    return {
        "argv": argv,
        "cwd": str(workdir),
        "env_additions": cfg.env_additions,
        "resolved_inputs": resolved_inputs,
        "resolved_outputs": resolved_outputs,
        "warnings": warnings,
    }


def run(
    cfg: ExecConfig,
    tool_spec: ToolSpec,
    request_args: Dict,
    extra_args: List[str],
    workdir: Path,
    artifact_dir: Path,
    timeout_s: Optional[int] = None,
) -> dict:
    env = _apply_env_additions(os.environ, cfg.env_additions)

    argv, resolved_inputs, resolved_outputs, warnings = build_argv_from_structured_request(
        tool_spec, request_args, extra_args, cwd=workdir, path_cfg=cfg.path_cfg
    )

    started = time.time()
    ts = time.strftime("%Y%m%d_%H%M%S")
    logs_dir = artifact_dir / "logs"
    stdout_path = logs_dir / f"{tool_spec.name}_{ts}.stdout.log"
    stderr_path = logs_dir / f"{tool_spec.name}_{ts}.stderr.log"

    artifact_dir.mkdir(parents=True, exist_ok=True)
    workdir.mkdir(parents=True, exist_ok=True)

    exit_code = run_subprocess(argv, env, workdir, stdout_path, stderr_path, timeout_s)

    finished = time.time()
    bin_sha, help_sha, ver_sha = compute_tool_fingerprints(Path(tool_spec.abs_path), tool_spec.help_raw, tool_spec.version_raw)

    input_hashes = {}
    for k, p in resolved_inputs.items():
        pp = Path(p)
        if pp.exists() and pp.is_file():
            input_hashes[k] = sha256_file(pp)
    output_hashes = {}
    for k, p in resolved_outputs.items():
        pp = Path(p)
        if pp.exists() and pp.is_file():
            output_hashes[k] = sha256_file(pp)

    manifest = RunManifest(
        sdk=tool_spec.sdk,
        sdk_version=tool_spec.sdk_version,
        tool_name=tool_spec.name,
        tool_abs_path=tool_spec.abs_path,
        argv=argv,
        cwd=str(workdir),
        env_additions=cfg.env_additions,
        started_at=started,
        finished_at=finished,
        exit_code=exit_code,
        stdout_path=str(stdout_path),
        stderr_path=str(stderr_path),
        inputs=resolved_inputs or None,
        outputs=resolved_outputs or None,
        input_hashes=input_hashes or None,
        output_hashes=output_hashes or None,
        tool_bin_sha256=bin_sha,
        tool_help_sha256=help_sha,
        tool_version_sha256=ver_sha,
        warnings=warnings or None,
    )
    manifest_path = artifact_dir / "manifest.json"
    write_manifest(manifest_path, manifest)

    return {
        "exit_code": exit_code,
        "artifact_dir": str(artifact_dir),
        "manifest_path": str(manifest_path),
        "stdout_path": str(stdout_path),
        "stderr_path": str(stderr_path),
        "warnings": warnings,
        "argv": argv,
    }
